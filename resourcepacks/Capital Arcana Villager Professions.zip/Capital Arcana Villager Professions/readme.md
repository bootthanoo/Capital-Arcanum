# Capital Arcana - Villager Professions Textures
- Version: 0.0.6

# Contained Villagers
- Glyph Scholar
- Wizard
- Bar Tender